import React from 'react'

const Pesquisa = () => {
  return (
    <div>Pesquisa</div>
  )
}

export default Pesquisa