import React from 'react'

const DisplayPodcast = () => {
  return (
    <div>DisplayPodcast</div>
  )
}

export default DisplayPodcast