import React from 'react'

const Perfil = () => {
  return (
    <div>Perfil</div>
  )
}

export default Perfil