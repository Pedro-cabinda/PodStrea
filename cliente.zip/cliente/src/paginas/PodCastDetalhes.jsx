import React from 'react'

const PodCastDetalhes = () => {
  return (
    <div>PodCastDetalhes</div>
  )
}

export default PodCastDetalhes