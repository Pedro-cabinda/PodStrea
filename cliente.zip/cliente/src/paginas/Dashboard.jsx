import React from 'react';
import styled from "styled-components";
import { Link } from 'react-router-dom';
import PodcastCard from '../componentes/PodcastCard';

const DashboardMain = styled.div`
padding:20px 30px;
padding-button:200px;
height:100%;
overflow-y:scroll;
overflow-x:hidden;
display:flex;
flex-direction:column;
gap:20px;
@media(max-width:768px){
    padding:6px 10px;
}
`;
const FiltroContainer = styled.div`
display: flex;
flex-direction: column;
${({ box, theme }) => box && `
background-color: ${theme.bg};
  border-radius: 10px;
  padding: 20px 30px;
`}
background-color: ${({ theme }) => theme.bg};
  border-radius: 10px;
  padding: 20px 30px;
`;
const Topicos = styled.div`
color: ${({ theme }) => theme.text_primary};
  font-size: 24px;
  font-weight: 540;
  display: flex;
  justify-content: space-between;
  align-items: center;
  @maedia (max-width: 768px){
    font-size: 18px;
  }
`;
const Podcasts = styled.div`
width:100%;
display: flex;
flex-wrap: wrap;
gap: 14px;
padding: 18px 6px;
@media (max-width: 550px){
  justify-content: center;
}
`;

const Span = styled.div`
color: ${({ theme }) => theme.text_secondary};
font-size: 16px;
font-weight: 400;
cursor: pointer;
@media (max-width: 768px){
  font-size: 14px;
}
color: ${({ theme }) => theme.primary};
&:hover{
  transition: 0.2s ease-in-out;
}
`;
const Dashboard = () => {
  return (
    <DashboardMain>
     <FiltroContainer>
       <Topicos>
        Mais Populares
        <Link to ={`/mostrarpodcasts/maispopular`} styled={{textDecoration:"none"}}>
          <Span>Mostrar Todos</Span>
        </Link>
       </Topicos>
       <Podcasts>
        <PodcastCard/>
        <PodcastCard/>
        <PodcastCard/>
        <PodcastCard/>
       </Podcasts>
     </FiltroContainer>

     <FiltroContainer>
       <Topicos>
        Comedia
        <Link to ={`/mostrarpodcasts/comedia`} styled={{textDecoration:"none"}}>
          <Span>Mostrar Todos</Span>
        </Link>
       </Topicos>
       <Podcasts>
        <PodcastCard/>
        <PodcastCard/>
        <PodcastCard/>
        <PodcastCard/>
       </Podcasts>
     </FiltroContainer>
    </DashboardMain>
  )
}

export default Dashboard