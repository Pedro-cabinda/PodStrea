import React from 'react'
import styled from 'styled-components';
import {HomeRounded,CloseRounded, SearchRounded, FavoriteRounded, UploadRounded, RadioRounded, LightModeRounded, LogoutRounded, DarkMode, DarkModeRounded, CloudUploadRounded} from "@mui/icons-material";
import LogoImage from "../imagens/Logo.png"
import {Link} from "react-router-dom";

const MenuContainer = styled.div`
flex:0.5;
flex-direction:column;
height:100vh;
display:flex;
background: ${({ theme }) => theme.bg};
color:${({ theme }) => theme.text_primary};
@media (max-width: 1100px) {
  position: fixed;
  z-index: 1000;
  width: 100%;
  max-width: 250px;
  left: ${({ abrirMenu}) => (abrirMenu? "0" : "-100%")};
  transition: 0.3s ease-in-out;
}

`;
const Image= styled.img`
   height:40px;

 `;
const Elementos = styled.div`
padding: 4px 16px;
display:flex;
flex-direction:row;
justify-content:flex-start;
align-items:center;
gap:12px;
cursor:pointer;
color:${({ theme }) => theme.text_secondary};
text-decoration:none!important;
&:hover {
  background-color:${({ theme }) => theme.text_primary};
}
`;
const NavText = styled.div`
padding: 12px 0px;
text-decoration:none!important;
`;

  const HR = styled.div`
    width:100%;
    height:1px;
    background-color:${({ theme }) => theme.text_secondary + 50};
    margin:10px 0px;
    
  `;
const Close = styled.div`
  display:none;
  @media(max-width:1100px){
  display:block;
}
`;
const Flex = styled.div`
display:flex;
flex-direction:row;
align-items:center;
justify-content:space-between;
padding: 12px 0px;
`;

const Logo = styled.div`
color:${({ theme }) => theme.primary};
display:flex;
align-items:cennter;
justify-content:  center;
gap:6px;
font-weight:bold;
font-size: 20px;
margin :16px 0px;
`;


const BarraLateral = ({ abrirMenu,setAbrirMenu,setDarkMode,DarkMode}) => {
  

const MenuItens =[
  
  {
  Link:"/",
  name:"Home",
  icon:<HomeRounded/>, 
  },
  {
  Link:"/Search",
  name:"Search",
  icon:<SearchRounded/>,
  },
  {
  Link:"/Favoritos",
  name:"Favoritos",
  icon:<FavoriteRounded/>,
  },
  {
  Link:"/Radio",
  name:"Radio",
  icon:<RadioRounded/>,   
  },

];

const button =[
  {
    
    fun:() =>console.log("upload"),
    name:"Upload",
    icon:<CloudUploadRounded/>,
  },
  {
  
    fun:()=>setDarkMode(!DarkMode),
    name:DarkMode?"Ligth Mode":"Dark Mode",
    icon:DarkMode?<LightModeRounded/>:<DarkModeRounded/>,
  },
  {
    fun:() =>console.log("logout"),
    name:"Log Out",
    icon:<LogoutRounded/>,
  }
  ];


  return <MenuContainer abrirMenu={abrirMenu}>
    <Flex>
    <Logo>
      <Image src={LogoImage}/>
      PODSTREAM
    </Logo>
    <Close onClick={()=>setAbrirMenu(false)}>
        <CloseRounded/> 
    </Close>
    </Flex>
    {
      MenuItens.map((item)=>(
        <Link to={item.Link} styled={{textDecoration:"none"}}>  
        <Elementos>
           {item.icon}    
            <NavText>{item.name}</NavText>
        </Elementos>
        </Link>
      ))
    }
    <HR/>
    {
      button.map((item)=>(
   
        <Elementos onClick={item.fun}>
           {item.icon}    
            <NavText>{item.name}</NavText>
        </Elementos>
      
      ))
    }
    
  </MenuContainer>
  
}

export default BarraLateral;