import { useState } from "react";
import styled, { ThemeProvider } from "styled-components";
import { lightTheme, darkTheme } from './utils/Themes';
import BarraLateral from "./componentes/BarraLateral";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import NavBar from "./componentes/NavBar";
import  Dashboard  from "./paginas/Dashboard";
import Pesquisa from "./paginas/Pesquisa";
import Favoritos from "./paginas/Favoritos";
import Perfil from "./paginas/Perfil";
import PodCastDetalhes from "./paginas/PodCastDetalhes";
import DisplayPodcast from "./paginas/DisplayPodcast";



const Container = styled.div`
  display: flex;
  background: ${({ theme }) => theme.bgLight};
  width: 100%;
  height: 100vh;
  overflow-x: hidden;
  overflow-y: hidden;
`;

const Frame = styled.div`
  display: flex;
  flex-direction: column;
  flex: 3;
`;

function App() {
  const [DarkMode, setDarkMode] = useState(true);
  const [abrirMenu, setAbrirMenu] = useState(true);

  return (
    <ThemeProvider theme={DarkMode ? darkTheme : lightTheme}>
      <BrowserRouter>

        <Container>
          { abrirMenu && (
          <BarraLateral
            abrirMenu={abrirMenu}
            setAbrirMenu={setAbrirMenu}
            setDarkMode={setDarkMode}
            DarkMode={DarkMode}
          />
          )
}
          <Frame>
            <NavBar abrirMenu={abrirMenu} setAbrirMenu={setAbrirMenu} />
            {/* 
            Roteando as Paginas 
            */}
            <Routes>
             <Route path="/" exact element={<Dashboard/>} />
             <Route path="/Pesquisar" exact element={<Pesquisa/>} />
             <Route path="/Favoritos" exact element={<Favoritos/>} />
             <Route path="/Perfil" exact element={<Perfil/>} />
             <Route path="/podcast:id" exact element={<PodCastDetalhes/>} />
             <Route path="/podcast/upload" exact element={<PodCastDetalhes/>} />
             <Route path="/mostrarpodcasts/:tipo" exact element={<DisplayPodcast/>} />
            </Routes>
          </Frame>
        </Container>
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;
